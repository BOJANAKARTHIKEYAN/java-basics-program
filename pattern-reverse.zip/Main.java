/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int a = sc.nextInt();
		int t=2*a-1;
		for (int row = 0;row<a;row++){
		    for (int col=0;col<t;col++){
		        System.out.print("*");
		    }
		    t=t-2;
		    System.out.println();
		}
	}
}