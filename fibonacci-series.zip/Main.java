/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		int a = sc.nextInt();
		for(int row=0;row<a ;row++){
		    for(int col=0;col<=row;col++){
		System.out.print("*");
		}
		System.out.println();
		}
	}
}